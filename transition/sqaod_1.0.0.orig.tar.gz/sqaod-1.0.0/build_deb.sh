#!/bin/bash
dpkg-buildpackage -us -uc
